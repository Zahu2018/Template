![macOS Sierra cursors for Windows and 200% scale](https://github.com/antiden/macOS-Sierra-cursors-for-Windows/blob/master/screenshot.jpg)

# Custom cursor macOS pack for Windows in 4K and scale 200%

Custom cursor macOS Sierra pack for Windows screens for 4K with scale 200%

## How to use it:

1. Select your resolution filder
2. Right click Install.inf and click «Install» 
3. Go to Control Panel → Mouse and choose «macOS Sierra 200» scheme. 
4. Apply and enjoy the best cursors ever!

## Authors

* **antiden** - [CODERTEAM_](https://coderteam.ru)
* Vector icons **daviddarnes** - [daviddarnes](https://github.com/daviddarnes/mac-cursors)

## License

This software is released under the [Apple User Agreement](http://images.apple.com/legal/sla/docs/OSX1011.pdf).

This project is licensed under the MIT License - see the [LICENSE.md](https://rem.mit-license.org/) file for details
